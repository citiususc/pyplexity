# Pyplexity

This package provides a simple interface to apply perplexity filters to any document. 
Furthermore, it provides a WARC and HTML bulk processor, with distributed capabilities.